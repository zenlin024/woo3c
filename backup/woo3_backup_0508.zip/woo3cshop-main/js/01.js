
		// $(document).ready(function(){
		// 	$("#slider").after("<div id='nav'>").cycle({
		// 		fx:"scrollHorz",//效果
		// 		timeout:3000,//停留時間
		// 		speed:300,//切換速度
		// 		pause:1,//滑鼠滑過暫停輪播
		// 		pager:"#nav"

		// 	});
		// });
	